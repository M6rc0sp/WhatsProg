#include <QApplication>

#include "whatsprog_main.h"
#include "mysocket.h"
#include "dados_cliente.h"

extern WhatsProgDadosCliente DC;
extern tcp_mysocket sock;

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  WhatsProgMain w;

  w.show();
  int result = a.exec();

  return result;
}
